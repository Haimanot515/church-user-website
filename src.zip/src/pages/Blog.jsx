import React, { useState, useEffect, useRef } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useTranslation } from "react-i18next";
import API from "../api/api.jsx";
import RichTextView from "../components/RichTextView";
import "./Blog.css";
import Spinner from "../components/Spinner";

const POSTS_PER_PAGE = 10;

// RichTextField-authored fields (title, description, content) are stored
// as HTML — strip tags before using them as plain text (headings, alt
// attributes, word counts for read time).
const stripHtml = (html) =>
  html ? html.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim() : "";

const Blog = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();

  // === Fetched posts state ===
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  // true when the posts currently shown came from the English
  // fallback because the active language had none (only applies when
  // no category filter is active — see fetchPosts)
  const [postsFallback, setPostsFallback] = useState(false);

  // Category list comes entirely from the backend. Each entry is now
  // { name, slug } — slug is the language-independent key sent to the
  // backend, name is the translated label shown in the UI. "All" is a
  // UI-only entry, prepended so people can clear the filter.
  const [categories, setCategories] = useState([{ name: "All", slug: "all" }]);
  const [categoriesLoading, setCategoriesLoading] = useState(true);
  const [categoriesError, setCategoriesError] = useState("");
  // true when the category list currently shown came from the
  // English fallback because the active language had none
  const [categoriesFallback, setCategoriesFallback] = useState(false);

  // === which category is currently selected in the nav ===
  // Stores the SLUG (language-independent), not the translated display
  // name. Defaults to "all" so the initial render shows every post.
  const [activeCategory, setActiveCategory] = useState("all");

  // set when the footer's category bar sent us here (it now passes a
  // slug in router state) — tells the "posts finished loading" effect
  // below that a scroll-to-top-of-list is still owed, so it fires once
  // the requested category's posts (not just whatever was loading
  // before) have actually arrived.
  const pendingFooterScroll = useRef(false);


  // ---------- Inlined category nav bar state/refs (formerly CategoryNav.jsx) ----------
  const catNavBarRef = useRef(null); // the sticky <nav> itself — measured for its height so scrolling to the post list doesn't leave the first post hidden underneath it
  const catViewportRef = useRef(null); // clipped outer window
  const catTrackRef = useRef(null); // the moving inner element
  const catPosRef = useRef(0); // current translateX, always in (-half, 0]
  const catHalfRef = useRef(0); // width of one copy of the list
  const catDrag = useRef({ active: false, moved: false, startX: 0, startPos: 0, downCat: null });
  const catPaused = useRef(false);
  const catResumeTimeout = useRef(null);

  // Ref on the first post's wrapper — the actual scroll target
  const postsSectionRef = useRef(null);

  const canLoopCategories = categories.length > 1;
  const catLoopItems = canLoopCategories ? [...categories, ...categories] : categories;

  const applyCatTransform = () => {
    if (catTrackRef.current) {
      catTrackRef.current.style.transform = `translateX(${catPosRef.current}px)`;
    }
  };

  const wrapCatPos = (pos) => {
    const half = catHalfRef.current;
    if (half <= 0) return 0;
    let p = pos % half;
    if (p > 0) p -= half;
    return p;
  };

  // Drives the endless-loop drift + measures/re-measures the track.
  useEffect(() => {
    const track = catTrackRef.current;
    if (!track || !canLoopCategories) return;

    // Measure once layout has settled.
    catHalfRef.current = track.scrollWidth / 2;
    catPosRef.current = 0;
    applyCatTransform();

    const prefersReduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    let rafId;
    const SPEED = 0.45; // px per frame, gentle drift

    const tick = () => {
      if (!prefersReduced && !catDrag.current.active && !catPaused.current) {
        catPosRef.current = wrapCatPos(catPosRef.current - SPEED);
        applyCatTransform();
      }
      rafId = requestAnimationFrame(tick);
    };
    rafId = requestAnimationFrame(tick);

    const onResize = () => {
      catHalfRef.current = track.scrollWidth / 2;
      catPosRef.current = wrapCatPos(catPosRef.current);
      applyCatTransform();
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener("resize", onResize);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categories]);

  const pauseCatAutoScroll = () => {
    catPaused.current = true;
    clearTimeout(catResumeTimeout.current);
  };
  const scheduleCatResume = () => {
    clearTimeout(catResumeTimeout.current);
    catResumeTimeout.current = setTimeout(() => {
      catPaused.current = false;
    }, 2200);
  };
  useEffect(() => () => clearTimeout(catResumeTimeout.current), []);

  const startCatDrag = (e) => {
    // data-cat now holds the SLUG (see render below), not the translated name
    const itemEl = e.target.closest?.(".cat-nav-item");
    catDrag.current = {
      active: true,
      moved: false,
      startX: e.clientX,
      startPos: catPosRef.current,
      downCat: itemEl ? itemEl.dataset.cat : null,
    };
    pauseCatAutoScroll();
    e.currentTarget.setPointerCapture?.(e.pointerId);
  };
  const moveCatDrag = (e) => {
    if (!catDrag.current.active) return;
    const delta = e.clientX - catDrag.current.startX;
    if (Math.abs(delta) > 4) catDrag.current.moved = true;
    catPosRef.current = wrapCatPos(catDrag.current.startPos + delta);
    applyCatTransform();
  };
  const endCatDrag = (e) => {
    if (!catDrag.current.active) return;
    catDrag.current.active = false;
    if (e?.currentTarget?.releasePointerCapture && e?.pointerId != null) {
      try {
        e.currentTarget.releasePointerCapture(e.pointerId);
      } catch {
        // no-op: pointer may already be released
      }
    }
    if (!catDrag.current.moved && catDrag.current.downCat) {
      handleCategoryClick(catDrag.current.downCat);
    }
    catDrag.current.moved = false;
    catDrag.current.downCat = null;
    scheduleCatResume();
  };
  // ---------- End inlined category nav bar logic ----------

  // Scrolls so the post list's top edge lands right below the sticky
  // category bar — no extra breathing-room offset, so it's the true top.
  const scrollToFirstPost = () => {
    if (!postsSectionRef.current) return;
    const navHeight = catNavBarRef.current?.getBoundingClientRect().height || 0;
    const targetY =
      postsSectionRef.current.getBoundingClientRect().top +
      window.scrollY -
      navHeight;
    window.scrollTo({ top: Math.max(targetY, 0), behavior: "smooth" });
  };

  const fetchPosts = async (pageNum) => {
    try {
      setLoading(true);
      setError("");
      if (pageNum === 1) setPostsFallback(false);

      const isFiltered = activeCategory && activeCategory !== "all";
      const params = {
        page: pageNum,
        limit: POSTS_PER_PAGE,
        // categorySlug is what the backend expects — a translated
        // category name will never match anything server-side.
        ...(isFiltered ? { categorySlug: activeCategory } : {}),
      };

      let res = await API.get("/posts", { params });
      let postsData = Array.isArray(res.data) ? res.data : res.data.posts;
      let pages = Array.isArray(res.data) ? 1 : (res.data.totalPages || 1);

      // Only retry in English when there's NO category filter active — a
      // specific category legitimately having zero posts should show the
      // empty state, not trigger a retry that can end up ignoring the
      // filter server-side and returning unrelated posts.
      if (pageNum === 1 && (!postsData || postsData.length === 0) && !isFiltered) {
        res = await API.get("/posts", {
          params,
          headers: { "Accept-Language": "en" },
        });
        postsData = Array.isArray(res.data) ? res.data : res.data.posts;
        pages = Array.isArray(res.data) ? 1 : (res.data.totalPages || 1);
        if (postsData && postsData.length > 0) setPostsFallback(true);
      }

      setPosts((prev) => (pageNum === 1 ? (postsData || []) : [...prev, ...(postsData || [])]));
      setTotalPages(pages);
    } catch (err) {
      console.log(err);
      setError(err.response?.data?.message || t("blog.posts.errorDefault"));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts(page);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, activeCategory, t]);

  const handleLoadMore = () => {
    if (page < totalPages) setPage((p) => p + 1);
  };

  // cat is now the SLUG (language-independent), read from data-cat
  const handleCategoryClick = (cat) => {
    setActiveCategory(cat);
    setPage(1);
    scrollToFirstPost();
  };

  // Fetch categories as { name, slug }. If the current language has zero
  // categories, re-fetch in English explicitly and flag the fallback.
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        setCategoriesLoading(true);
        setCategoriesError("");
        setCategoriesFallback(false);

        let res = await API.get("/categories");
        let raw = Array.isArray(res.data) ? res.data : res.data.categories;
        let cats = (raw || [])
          .map((c) => (c && c.name && c.slug ? { name: c.name, slug: c.slug } : null))
          .filter(Boolean);

        if (cats.length === 0) {
          res = await API.get("/categories", {
            headers: { "Accept-Language": "en" },
          });
          raw = Array.isArray(res.data) ? res.data : res.data.categories;
          cats = (raw || [])
            .map((c) => (c && c.name && c.slug ? { name: c.name, slug: c.slug } : null))
            .filter(Boolean);
          if (cats.length > 0) setCategoriesFallback(true);
        }

        if (cats.length > 0) {
          setCategories([{ name: "All", slug: "all" }, ...cats]);
        }
      } catch (err) {
        console.log(err);
        setCategoriesError(err.response?.data?.message || t("blog.categoryNav.errorDefault"));
      } finally {
        setCategoriesLoading(false);
      }
    };
    fetchCategories();
  }, [t]);

  // Pick up a category slug passed in via router state — e.g. from the
  // footer's category bar (navigate("/projects", { state: { categorySlug } })).
  // Applies the filter and marks a scroll as pending until that
  // category's posts have actually finished loading.
  useEffect(() => {
    if (location.state?.categorySlug) {
      setActiveCategory(location.state.categorySlug);
      setPage(1);
      pendingFooterScroll.current = true;
      // Clear the state so refreshing or navigating back doesn't re-trigger it.
      navigate(location.pathname, { replace: true, state: {} });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.state]);

  // Once the requested category's posts have actually loaded, scroll
  // to the very top of the post list. Waiting on `loading` (rather than a
  // fixed timeout) means the landing spot is accurate no matter how long
  // the fetch takes.
  useEffect(() => {
    if (pendingFooterScroll.current && !loading) {
      pendingFooterScroll.current = false;
      requestAnimationFrame(() => scrollToFirstPost());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading]);

  const getCategoryName = (post) =>
    typeof post.category === "object" && post.category !== null
      ? post.category.name
      : post.category || t("blog.posts.defaultCategory");

  const getAuthorName = (post) =>
    typeof post.author === "object" && post.author !== null
      ? post.author.name
      : post.author || t("blog.posts.defaultAuthor");

  const getFormattedDate = (post) =>
    post.publishedAt || post.createdAt
      ? new Date(post.publishedAt || post.createdAt).toLocaleDateString("en-US", {
          month: "long",
          day: "numeric",
          year: "numeric",
        })
      : "";

  const getReadTime = (post) => {
    // Strip tags first — otherwise every "<p>", "<span style=...>" etc.
    // gets counted as a word and inflates the estimate.
    const plain = stripHtml(post.content || post.description || "");
    const words = plain.split(/\s+/).filter(Boolean).length;
    const minutes = Math.max(1, Math.round(words / 200));
    return `${minutes} ${t("blog.posts.readTimeSuffix")}`;
  };

  // Translated display name for the currently active category slug —
  // used only for the "no posts in <category>" message below.
  const activeCategoryLabel =
    categories.find((c) => c.slug === activeCategory)?.name || activeCategory;

  const isFiltered = activeCategory && activeCategory !== "all";

  return (
    <div className="church-portal">
      <div className="cloud-layer">
        <div className="cloud cloud-a" />
        <div className="cloud cloud-b" />
      </div>

      <section className="hero-blog">
        <div className="wrapper">
          <h1 className="display">{t("blog.hero.title")}</h1>
          <p>{t("blog.hero.description")}</p>
        </div>
      </section>

      {/* NAV — inlined (formerly <CategoryNav />) */}
      <nav className="cat-nav-bar" aria-label={t("blog.categoryNav.ariaLabel")} ref={catNavBarRef}>
        <div
          className="cat-nav-track"
          ref={catViewportRef}
          onPointerDown={startCatDrag}
          onPointerMove={moveCatDrag}
          onPointerUp={endCatDrag}
          onPointerCancel={endCatDrag}
        >
          <div className="cat-nav-scroll" ref={catTrackRef}>
            {catLoopItems.map((cat, i) => (
              <span
                key={`${cat.slug}-${i}`}
                data-cat={cat.slug}
                className={`cat-nav-item${cat.slug === activeCategory ? " active" : ""}`}
              >
                {cat.slug === "all" ? t("blog.categoryNav.all") : cat.name}
              </span>
            ))}
          </div>
        </div>
      </nav>

      {/* note shown when the category list fell back to English */}
      {categoriesFallback && (
        <p style={{ textAlign: "center", fontSize: "0.85rem", color: "#888", margin: "10px 0 0 0" }}>
          {t("blog.categoryNav.fallbackNotice")}
        </p>
      )}
      {categoriesError && (
        <p style={{ color: "red", textAlign: "center", margin: "10px 0 0 0" }}>{categoriesError}</p>
      )}

      <section className="blog-list-section" ref={postsSectionRef}>
        <div className="wrapper">
          {error && <p style={{ color: "red", textAlign: "center" }}>{error}</p>}

          {/* note shown when the posts fell back to English (only relevant
              when no category filter is active — see fetchPosts) */}
          {postsFallback && (
            <p style={{ textAlign: "center", fontSize: "0.85rem", color: "#888", marginBottom: "24px" }}>
              {t("blog.posts.fallbackNotice")}
            </p>
          )}

          {loading && posts.length === 0 ? (
            <Spinner />
          ) : posts.length === 0 ? (
            <p style={{ textAlign: "center" }}>
              {activeCategory === "all"
                ? t("blog.posts.noneAll")
                : t("blog.posts.noneCategory", { category: activeCategoryLabel })}
            </p>
          ) : (
            posts.map((post, index) => (
              <React.Fragment key={post.id || index}>
                <div className={`post-row${index % 2 === 1 ? " reverse" : ""}`}>
                  <Link to={`/projects/${post.id}`} className="post-media">
                    <img loading="lazy" decoding="async" src={post.imageUrl} alt={stripHtml(post.title)} />
                  </Link>
                  <div className="post-copy">
                    <div className="post-meta">
                      <span className="tag">{getCategoryName(post)}</span>
                      <span className="dot" />
                      <span className="meta-plain">{getFormattedDate(post)}</span>
                      <span className="dot" />
                      <span className="meta-plain">{getReadTime(post)}</span>
                    </div>
                    <h3>{stripHtml(post.title)}</h3>
                    <RichTextView className="desc" html={post.description} />
                    <p className="byline">By {getAuthorName(post)}</p>
                    <Link to={`/projects/${post.id}`} className="read-more">
                      {t("blog.posts.readMoreButton")}
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9 4L17 12L9 20" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </Link>
                  </div>
                </div>
                {index < posts.length - 1 && (
                  <div className="row-divider">
                    <span className="h-string" />
                    <svg width="18" height="26" viewBox="0 0 18 26" xmlns="http://www.w3.org/2000/svg">
                      <rect x="7" y="0" width="4" height="26" fill="var(--gold)" opacity="0.75" />
                      <rect x="0" y="6" width="18" height="4" fill="var(--gold)" opacity="0.75" />
                    </svg>
                    <span className="h-string" />
                  </div>
                )}
              </React.Fragment>
            ))
          )}

          {page < totalPages && (
            <div className="load-more-wrap">
              <button className="load-more-btn" onClick={handleLoadMore} disabled={loading}>
                {loading ? t("blog.posts.loadingMoreButton") : t("blog.posts.loadMoreButton")}
              </button>
            </div>
          )}
        </div>
      </section>

    </div>
  );
};

export default Blog;