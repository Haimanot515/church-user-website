import React, { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import API from "../api/api.jsx";
import { stripHtml, Rich } from "../components/RichTextView";
import "./Home.css";

const POSTS_PER_PAGE = 10;

// Rich text (formatted titles/previews) comes from the shared RichTextView file:
// <Rich /> keeps colors/bold/links, stripHtml gives plain text for alt/aria.

const Home = () => {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [hero, setHero] = useState(null);
  // true when the hero currently shown came from the English
  // fallback because the active language had none
  const [heroFallback, setHeroFallback] = useState(false);
  const [heroLoading, setHeroLoading] = useState(true);
  const [priest, setPriest] = useState(null);
  // true when the priest/about content currently shown came from the
  // English fallback because the active language had none
  const [priestFallback, setPriestFallback] = useState(false);
  const [priestLoading, setPriestLoading] = useState(true);
  const [photoIndex, setPhotoIndex] = useState(0);
  const [photos, setPhotos] = useState([]);
  // photosLoading only gates the very first load of the section (shows the
  // full-section spinner). photosPageLoading gates subsequent page turns
  // (Next/Prev across a page boundary) and only shows a small overlay so
  // the carousel + arrows stay mounted and visible the whole time.
  const [photosLoading, setPhotosLoading] = useState(true);
  const [photosPageLoading, setPhotosPageLoading] = useState(false);
  const photosLoadedOnce = useRef(false);
  // Remembers which photo to show once the next/previous page arrives:
  // 0 = first photo (going forward), "last" = last photo (going back).
  const pendingPhotoIndex = useRef(0);
  // About section: the photo is a square whose side equals the height of
  // the text column next to it (measured live, see effect below).
  const priestTextRef = useRef(null);
  const [priestPhotoSize, setPriestPhotoSize] = useState(340);   // photo width (clamped)
  const [priestTextHeight, setPriestTextHeight] = useState(340); // exact text height = photo height
  const [photosError, setPhotosError] = useState("");
  const [photosPage, setPhotosPage] = useState(1);
  const [photosTotalPages, setPhotosTotalPages] = useState(1);
  const [showSponsored, setShowSponsored] = useState(true);
  // the sponsored block shouldn't appear immediately on page load — it
  // only becomes eligible to render 10s after mount.
  const [sponsoredDelayPassed, setSponsoredDelayPassed] = useState(false);

  // Promotions: now a rotating list of (up to) the 5 most recent, instead
  // of a single promotion. promotionIndex is advanced every 5s.
  const [promotions, setPromotions] = useState([]);
  const [promotionIndex, setPromotionIndex] = useState(0);
  const [promotionLoading, setPromotionLoading] = useState(true);
  // true when the promotions currently shown came from the English
  // fallback because the active language had none
  const [promotionFallback, setPromotionFallback] = useState(false);

  const [sermons, setSermons] = useState([]);
  const [sermonsLoading, setSermonsLoading] = useState(true);
  const [sermonsError, setSermonsError] = useState("");
  const [sermonsPage, setSermonsPage] = useState(1);
  const [sermonsTotalPages, setSermonsTotalPages] = useState(1);
  // true when the sermons currently shown came from the English
  // fallback because the active language/category combo had no posts
  const [sermonsFallback, setSermonsFallback] = useState(false);

  const [trending, setTrending] = useState([]);
  const [trendingLoading, setTrendingLoading] = useState(true);
  const [trendingError, setTrendingError] = useState("");
  const [trendingPage, setTrendingPage] = useState(1);
  const [trendingTotalPages, setTrendingTotalPages] = useState(1);
  // true when trending posts currently shown came from the English
  // fallback because the active language had none
  const [trendingFallback, setTrendingFallback] = useState(false);

  const [recommended, setRecommended] = useState([]);
  const [recommendedLoading, setRecommendedLoading] = useState(true);
  const [recommendedError, setRecommendedError] = useState("");
  const [recommendedPage, setRecommendedPage] = useState(1);
  const [recommendedTotalPages, setRecommendedTotalPages] = useState(1);
  // true when recommended posts currently shown came from the English
  // fallback because the active language had none
  const [recommendedFallback, setRecommendedFallback] = useState(false);

  // Reusable inline loading spinner — shown while a section's data is
  // being fetched from the backend so the user never sees hardcoded
  // frontend placeholder content before the real data arrives.
  const Spinner = ({ light }) => (
    <div className="loading-spinner-wrap">
      <div className={`loading-spinner${light ? " light" : ""}`} />
    </div>
  );

  // "All" is always first, so users can clear the category filter.
  // Each entry is { name, slug } — slug is the language-independent
  // key sent to the backend, name is the translated label shown in the UI.
  const [categories, setCategories] = useState([{ name: "All", slug: "all" }]);
  const [categoriesLoading, setCategoriesLoading] = useState(true);
  const [categoriesError, setCategoriesError] = useState("");
  // true when the categories currently shown came from the English
  // fallback because the active language had none
  const [categoriesFallback, setCategoriesFallback] = useState(false);

  // default to "all" so the initial render shows every post, no filter.
  // activeCategory stores the SLUG (language-independent), not the
  // translated display name.
  const [activeCategory, setActiveCategory] = useState("all");

  // ---------- Inlined category nav bar state/refs (formerly CategoryNav.jsx) ----------
  const catNavBarRef = useRef(null); // the sticky <nav> itself — used to measure its height so scrolling to a section doesn't leave it hidden underneath the sticky bar
  const catViewportRef = useRef(null); // clipped outer window
  const catTrackRef = useRef(null); // the moving inner element
  const catPosRef = useRef(0); // current translateX, always in (-half, 0]
  const catHalfRef = useRef(0); // width of one copy of the list
  const catDrag = useRef({ active: false, moved: false, startX: 0, startPos: 0, downCat: null });
  const catPaused = useRef(false);
  const catResumeTimeout = useRef(null);

  const canLoopCategories = categories.length > 1;
  const catLoopItems = canLoopCategories ? [...categories, ...categories] : categories;

  const applyCatTransform = () => {
    if (catTrackRef.current) {
      catTrackRef.current.style.transform = `translateX(${catPosRef.current}px)`;
    }
  };

  const wrapCatPos = (pos) => {
    const half = catHalfRef.current;
    if (half <= 0) return 0;
    let p = pos % half;
    if (p > 0) p -= half;
    return p;
  };

  // Drives the endless-loop drift + measures/re-measures the track.
  useEffect(() => {
    const track = catTrackRef.current;
    if (!track || !canLoopCategories) return;

    // Measure once layout has settled.
    catHalfRef.current = track.scrollWidth / 2;
    catPosRef.current = 0;
    applyCatTransform();

    const prefersReduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    let rafId;
    const SPEED = 0.45; // px per frame, gentle drift

    const tick = () => {
      if (!prefersReduced && !catDrag.current.active && !catPaused.current) {
        catPosRef.current = wrapCatPos(catPosRef.current - SPEED);
        applyCatTransform();
      }
      rafId = requestAnimationFrame(tick);
    };
    rafId = requestAnimationFrame(tick);

    const onResize = () => {
      catHalfRef.current = track.scrollWidth / 2;
      catPosRef.current = wrapCatPos(catPosRef.current);
      applyCatTransform();
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener("resize", onResize);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categories]);

  const pauseCatAutoScroll = () => {
    catPaused.current = true;
    clearTimeout(catResumeTimeout.current);
  };
  const scheduleCatResume = () => {
    clearTimeout(catResumeTimeout.current);
    catResumeTimeout.current = setTimeout(() => {
      catPaused.current = false;
    }, 2200);
  };
  useEffect(() => () => clearTimeout(catResumeTimeout.current), []);

  const startCatDrag = (e) => {
    // Capture which category (if any) sits under the pointer right now.
    // We can't rely on the span's own onClick firing later, because
    // setPointerCapture below redirects the pointerup (and the click the
    // browser synthesizes from it) to the track div, not to the span —
    // so a plain tap on a category was silently swallowed. Grabbing the
    // category here, and firing selection manually from endCatDrag,
    // sidesteps that entirely.
    const itemEl = e.target.closest?.(".cat-nav-item");
    catDrag.current = {
      active: true,
      moved: false,
      startX: e.clientX,
      startPos: catPosRef.current,
      // data-cat now holds the SLUG, see render below
      downCat: itemEl ? itemEl.dataset.cat : null,
    };
    pauseCatAutoScroll();
    // Pointer capture keeps move/up events firing on this element even if
    // the pointer drifts outside its (fairly thin) bounds mid-drag — on
    // mouse, touch, or pen alike — so a fast or slightly-off-axis drag
    // never gets cut short before reaching the edges.
    e.currentTarget.setPointerCapture?.(e.pointerId);
  };
  const moveCatDrag = (e) => {
    if (!catDrag.current.active) return;
    const delta = e.clientX - catDrag.current.startX;
    if (Math.abs(delta) > 4) catDrag.current.moved = true;
    catPosRef.current = wrapCatPos(catDrag.current.startPos + delta);
    applyCatTransform();
  };
  const endCatDrag = (e) => {
    if (!catDrag.current.active) return;
    catDrag.current.active = false;
    if (e?.currentTarget?.releasePointerCapture && e?.pointerId != null) {
      try {
        e.currentTarget.releasePointerCapture(e.pointerId);
      } catch {
        // no-op: pointer may already be released
      }
    }
    // Fire the selection here instead of via the span's onClick — this is
    // the event that actually reaches us reliably.
    if (!catDrag.current.moved && catDrag.current.downCat) {
      handleCategoryClick(catDrag.current.downCat);
    }
    catDrag.current.moved = false;
    catDrag.current.downCat = null;
    scheduleCatResume();
  };
  // ---------- End inlined category nav bar logic ----------

  // Photo navigation. At a page boundary we load the neighbouring page and
  // remember (via pendingPhotoIndex) which photo to land on: the FIRST photo
  // when going forward, the LAST photo when going back.
  const showPrevPhoto = () => {
    if (photosPageLoading) return;
    if (photoIndex > 0) {
      setPhotoIndex((i) => i - 1);
    } else if (photosPage > 1) {
      pendingPhotoIndex.current = "last";
      setPhotosPage((p) => p - 1);
    }
  };

  const showNextPhoto = () => {
    if (photosPageLoading) return;
    if (photoIndex < photos.length - 1) {
      setPhotoIndex((i) => i + 1);
    } else if (photosPage < photosTotalPages) {
      pendingPhotoIndex.current = 0;
      setPhotosPage((p) => p + 1);
    }
  };

  const angelScrollRef = useRef(null);
  const sermonSectionRef = useRef(null);
  const scrollAngels = (direction) => {
    if (angelScrollRef.current) {
      const amount = angelScrollRef.current.clientWidth * 0.8;
      angelScrollRef.current.scrollBy({ left: direction * amount, behavior: 'smooth' });
    }
  };

  const videos = [
    {
      title: "Joey's Journey: A Testimony of Coming Home",
      tag: "NOW PLAYING",
      img: "https://images.unsplash.com/photo-1594990375715-2d008aaaa31b?auto=format&fit=crop&w=900&q=80",
      alt: "Blue and gold Orthodox cathedral interior",
      youtubeId: "YBJE7mJfEYk"
    },
    {
      title: "Sunday Highlights: Hope in Hard Seasons, Week 3",
      img: "https://images.unsplash.com/photo-1627573897879-1eff66f2c228?auto=format&fit=crop&w=200&q=80",
      alt: "Low angle view of Orthodox cathedral interior",
      youtubeId: "Y_O0yIoz8Hs"
    },
    {
      title: "Behind the Scenes: Our Worship Team at Rehearsal",
      img: "https://images.unsplash.com/photo-1739061749940-124120c10264?auto=format&fit=crop&w=200&q=80",
      alt: "Priest holding a cross during service",
      youtubeId: "YBJE7mJfEYk"
    },
    {
      title: "Youth Retreat Recap: Faith, Fire Pits & Fellowship",
      img: "https://images.unsplash.com/photo-1649105703438-0992d6844823?auto=format&fit=crop&w=200&q=80",
      alt: "Priest standing in front of a cross",
      youtubeId: "Y_O0yIoz8Hs"
    },
    {
      title: "Missions Update: Stories from the Field",
      img: "https://images.unsplash.com/photo-1612005660287-62b37fad2eb5?auto=format&fit=crop&w=200&q=80",
      alt: "Orthodox cross atop a church dome",
      youtubeId: "YBJE7mJfEYk"
    }
  ];

  const [activeVideoId, setActiveVideoId] = useState(videos[0].youtubeId);
  const [activeVideoTitle, setActiveVideoTitle] = useState(videos[0].title);

  useEffect(() => {
    const fetchContent = async () => {
      try {
        const response = await API.get("/landingheros");
        setData(Array.isArray(response.data) ? response.data[0] : response.data);
      } catch (err) { console.error("Error:", err); }
    };
    fetchContent();
  }, []);

  // Hero: try current language first; if none, retry explicitly in English
  // and flag the fallback so the UI can show a note about it.
  useEffect(() => {
    const fetchHero = async () => {
      try {
        setHeroLoading(true);
        setHeroFallback(false);

        let heroRes = await API.get("/homeheros");
        let heroData = Array.isArray(heroRes.data) ? heroRes.data[0] : heroRes.data;

        if (!heroData) {
          heroRes = await API.get("/homeheros", {
            headers: { "Accept-Language": "en" },
          });
          heroData = Array.isArray(heroRes.data) ? heroRes.data[0] : heroRes.data;
          if (heroData) setHeroFallback(true);
        }

        setHero(heroData || null);
      } catch (err) {
        console.error("Error:", err);
      } finally {
        setHeroLoading(false);
      }
    };
    fetchHero();
  }, [t]);

  // Priest/About: try current language first; if none, retry explicitly in
  // English and flag the fallback so the UI can show a note about it.
  useEffect(() => {
    const fetchPriest = async () => {
      try {
        setPriestLoading(true);
        setPriestFallback(false);

        let aboutRes = await API.get("/about");
        let aboutData = Array.isArray(aboutRes.data) ? aboutRes.data : [aboutRes.data];
        let latest = aboutData
          .filter(Boolean)
          .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];

        if (!latest) {
          aboutRes = await API.get("/about", {
            headers: { "Accept-Language": "en" },
          });
          aboutData = Array.isArray(aboutRes.data) ? aboutRes.data : [aboutRes.data];
          latest = aboutData
            .filter(Boolean)
            .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
          if (latest) setPriestFallback(true);
        }

        setPriest(latest || null);
      } catch (err) {
        console.error("Error:", err);
      } finally {
        setPriestLoading(false);
      }
    };
    fetchPriest();
  }, [t]);

  // Promotions: fetch the 5 most recent. Try current language first; if
  // page 1 is empty, retry explicitly in English and flag the fallback so
  // the UI can show a note about it.
  useEffect(() => {
    const fetchPromotions = async () => {
      try {
        setPromotionLoading(true);
        setPromotionFallback(false);

        let res = await API.get("/promotions/latest", { params: { limit: 5 } });
        let list = Array.isArray(res.data) ? res.data : (res.data ? [res.data] : []);

        if (list.length === 0) {
          res = await API.get("/promotions/latest", {
            params: { limit: 5 },
            headers: { "Accept-Language": "en" },
          });
          list = Array.isArray(res.data) ? res.data : (res.data ? [res.data] : []);
          if (list.length > 0) setPromotionFallback(true);
        }

        setPromotions(list.slice(0, 5));
        setPromotionIndex(0);
      } catch (err) {
        console.log(err);
        setPromotions([]);
      } finally {
        setPromotionLoading(false);
      }
    };
    fetchPromotions();
  }, [t]);

  // About: the photo is a square whose side equals the text column's height.
  // This is stable (no shaking) because on wide screens the text column has a
  // FIXED width in CSS (.about-text), so its height never depends on the
  // photo size. On narrow screens CSS ignores this value entirely.
  useEffect(() => {
    if (priestLoading) return;
    const el = priestTextRef.current;
    if (!el) return;
    const update = () => {
      const h = Math.round(el.getBoundingClientRect().height);
      const next = Math.min(Math.max(h, 260), 420);
      setPriestPhotoSize((prev) => (Math.abs(prev - next) > 1 ? next : prev));
      // photo HEIGHT is exactly the text height (not clamped)
      if (h > 0) setPriestTextHeight((prev) => (Math.abs(prev - h) > 1 ? h : prev));
    };
    update();
    if (typeof ResizeObserver === "undefined") {
      window.addEventListener("resize", update);
      return () => window.removeEventListener("resize", update);
    }
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, [priestLoading, priest, i18n.language]);

  // The sponsored block shouldn't appear immediately on page load — it
  // only becomes eligible to render 10s after mount.
  useEffect(() => {
    const timer = setTimeout(() => setSponsoredDelayPassed(true), 10000);
    return () => clearTimeout(timer);
  }, []);

  // Rotate to the next promotion every 5 seconds — only once the sponsored
  // block has actually appeared (i.e. after the initial 5s reveal delay),
  // so the first rotation always happens 5s after the user first sees it.
  useEffect(() => {
    if (!sponsoredDelayPassed || promotions.length <= 1) return;
    const interval = setInterval(() => {
      setPromotionIndex((i) => (i + 1) % promotions.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [sponsoredDelayPassed, promotions.length]);

  useEffect(() => {
    const fetchPhotos = async (page) => {
      try {
        // Only show the full-section spinner on the very first load of
        // this section. On every later page turn, keep the carousel (and
        // its arrows) mounted and use a small overlay spinner instead —
        // otherwise the whole section unmounts on every Next/Prev click
        // at a page boundary, which looked like the button did nothing.
        if (!photosLoadedOnce.current) {
          setPhotosLoading(true);
        } else {
          setPhotosPageLoading(true);
        }
        setPhotosError("");

        const res = await API.get("/media/type/photo", {
          params: {
            page,
            limit: 10,
          },
        });

        const mediaData = Array.isArray(res.data) ? res.data : res.data.media;
        const list = mediaData || [];
        setPhotos(list);
        // Land on the first photo (going forward / first load) or the last
        // photo of the page (going back across a page boundary).
        setPhotoIndex(
          pendingPhotoIndex.current === "last"
            ? Math.max(list.length - 1, 0)
            : 0
        );
        pendingPhotoIndex.current = 0;
        setPhotosTotalPages(res.data.totalPages || 1);
      } catch (err) {
        console.log(err);
        pendingPhotoIndex.current = 0;
        setPhotosError(err.response?.data?.message || t("home.photos.errorDefault"));
      } finally {
        setPhotosLoading(false);
        setPhotosPageLoading(false);
        photosLoadedOnce.current = true;
      }
    };
    fetchPhotos(photosPage);
  }, [photosPage, t]);

  // "all" fetches every post with no category filter, same limit as every category.
  // On the first page of a language/category combo, if nothing comes
  // back, re-fetch that same page explicitly in English and flag the
  // fallback so the UI can show a note about it.
  useEffect(() => {
    const fetchSermons = async (page) => {
      try {
        setSermonsLoading(true);
        setSermonsError("");
        if (page === 1) setSermonsFallback(false);

        const baseParams = {
          page,
          limit: POSTS_PER_PAGE,
          // slug is language-independent — this is what the backend
          // now expects instead of a translated category name
          ...(activeCategory && activeCategory !== "all" ? { categorySlug: activeCategory } : {}),
        };

        let res = await API.get("/posts", { params: baseParams });
        let postsData = Array.isArray(res.data) ? res.data : res.data.posts;

        // Only attempt the fallback on a fresh load (page 1) — a "Load
        // More" click on page > 1 should never silently switch language.
        if (page === 1 && (!postsData || postsData.length === 0)) {
          res = await API.get("/posts", {
            params: baseParams,
            headers: { "Accept-Language": "en" },
          });
          postsData = Array.isArray(res.data) ? res.data : res.data.posts;

          if (postsData && postsData.length > 0) {
            setSermonsFallback(true);
          }
        }

        // Append on "Load More" (page > 1), replace on first load / category switch
        setSermons((prev) => (page === 1 ? (postsData || []) : [...prev, ...(postsData || [])]));
        setSermonsTotalPages(res.data.totalPages || 1);
      } catch (err) {
        console.log(err);
        setSermonsError(err.response?.data?.message || t("home.sermons.errorDefault"));
      } finally {
        setSermonsLoading(false);
      }
    };
    fetchSermons(sermonsPage);
  }, [sermonsPage, activeCategory, t]);

  // Trending: try current language first; if page 1 is empty, retry
  // explicitly in English and flag the fallback so the UI can show a note.
  useEffect(() => {
    const fetchTrending = async (page) => {
      try {
        setTrendingLoading(true);
        setTrendingError("");
        if (page === 1) setTrendingFallback(false);

        const baseParams = { page, limit: POSTS_PER_PAGE };

        let res = await API.get("/posts/trending", { params: baseParams });
        let postsData = Array.isArray(res.data) ? res.data : res.data.posts;

        if (page === 1 && (!postsData || postsData.length === 0)) {
          res = await API.get("/posts/trending", {
            params: baseParams,
            headers: { "Accept-Language": "en" },
          });
          postsData = Array.isArray(res.data) ? res.data : res.data.posts;

          if (postsData && postsData.length > 0) {
            setTrendingFallback(true);
          }
        }

        setTrending(postsData || []);
        setTrendingTotalPages(res.data.totalPages || 1);
      } catch (err) {
        console.log(err);
        setTrendingError(err.response?.data?.message || t("home.trending.errorDefault"));
      } finally {
        setTrendingLoading(false);
      }
    };
    fetchTrending(trendingPage);
  }, [trendingPage, t]);

  // Recommended: try current language first; if page 1 is empty, retry
  // explicitly in English and flag the fallback so the UI can show a note.
  useEffect(() => {
    const fetchRecommended = async (page) => {
      try {
        setRecommendedLoading(true);
        setRecommendedError("");
        if (page === 1) setRecommendedFallback(false);

        const baseParams = { page, limit: POSTS_PER_PAGE };

        let res = await API.get("/posts/recommended", { params: baseParams });
        let postsData = Array.isArray(res.data) ? res.data : res.data.posts;

        if (page === 1 && (!postsData || postsData.length === 0)) {
          res = await API.get("/posts/recommended", {
            params: baseParams,
            headers: { "Accept-Language": "en" },
          });
          postsData = Array.isArray(res.data) ? res.data : res.data.posts;

          if (postsData && postsData.length > 0) {
            setRecommendedFallback(true);
          }
        }

        setRecommended(postsData || []);
        setRecommendedTotalPages(res.data.totalPages || 1);
      } catch (err) {
        console.log(err);
        setRecommendedError(err.response?.data?.message || t("home.recommended.errorDefault"));
      } finally {
        setRecommendedLoading(false);
      }
    };
    fetchRecommended(recommendedPage);
  }, [recommendedPage, t]);

  // prepend "All" (UI-only, never comes from the DB) before the fetched
  // categories. Each entry is stored as { name, slug } — slug is the
  // language-independent key ("travel") used for filtering, name is the
  // translated label ("Travel" / "Viaggi" / "ጉዞ") shown in the nav bar.
  // If the current language has zero categories, re-fetch in English
  // explicitly and flag the fallback so the UI can show a note about it.
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        setCategoriesLoading(true);
        setCategoriesError("");
        setCategoriesFallback(false);

        let res = await API.get("/categories");
        let raw = Array.isArray(res.data) ? res.data : res.data.categories;
        let cats = (raw || [])
          .map((c) => (c && c.name && c.slug ? { name: c.name, slug: c.slug } : null))
          .filter(Boolean);

        if (cats.length === 0) {
          res = await API.get("/categories", {
            headers: { "Accept-Language": "en" },
          });
          raw = Array.isArray(res.data) ? res.data : res.data.categories;
          cats = (raw || [])
            .map((c) => (c && c.name && c.slug ? { name: c.name, slug: c.slug } : null))
            .filter(Boolean);

          if (cats.length > 0) {
            setCategoriesFallback(true);
          }
        }

        if (cats.length > 0) {
          setCategories([{ name: "All", slug: "all" }, ...cats]);
        }
      } catch (err) {
        console.log(err);
        setCategoriesError(err.response?.data?.message || t("home.categoryNav.errorDefault"));
      } finally {
        setCategoriesLoading(false);
      }
    };
    fetchCategories();
  }, [t]);

  // Plain scrollIntoView({block:"start"}) aligns the section's top edge with
  // the very top of the viewport — right where the sticky .cat-nav-bar sits.
  // This measures the sticky bar's actual height and scrolls just far enough
  // that the first post lands right below it instead.
  const scrollToSermons = () => {
    if (!sermonSectionRef.current) return;
    const navHeight = catNavBarRef.current?.getBoundingClientRect().height || 0;
    const targetY =
      sermonSectionRef.current.getBoundingClientRect().top +
      window.scrollY -
      navHeight -
      12; // small breathing room below the bar
    window.scrollTo({ top: Math.max(targetY, 0), behavior: "smooth" });
  };

  // cat is now the SLUG (language-independent), read from data-cat
  const handleCategoryClick = (cat) => {
    setActiveCategory(cat);
    setSermonsPage(1);
    scrollToSermons();
  };

  const handleLoadMoreSermons = () => {
    if (sermonsPage < sermonsTotalPages) setSermonsPage((p) => p + 1);
  };

  const goToTrendingPage = (page) => {
    if (page < 1 || page > trendingTotalPages) return;
    setTrendingPage(page);
  };

  const goToRecommendedPage = (page) => {
    if (page < 1 || page > recommendedTotalPages) return;
    setRecommendedPage(page);
  };

  const pageButtonStyle = (disabled) => ({
    padding: "8px 16px",
    background: disabled ? "#e5e7eb" : "#2563eb",
    color: disabled ? "#999" : "#fff",
    border: "none",
    borderRadius: "6px",
    cursor: disabled ? "not-allowed" : "pointer",
  });

  // The currently-displayed promotion, derived from the rotating list.
  const promotion = promotions[promotionIndex] || null;
  const shouldShowSponsored =
    showSponsored && sponsoredDelayPassed && !promotionLoading && !!promotion;

  // Translated display name for the currently active category slug —
  // used only for the "no posts in <category>" message below.
  const activeCategoryLabel =
    categories.find((c) => c.slug === activeCategory)?.name || activeCategory;

  return (
    <div className={`church-portal lang-${i18n.language}`}>
      <div className="cloud-layer">
        <div className="cloud cloud-a" />
        <div className="cloud cloud-b" />
        <div className="cloud cloud-c" />
      </div>

      {shouldShowSponsored && (
      <div className="sponsored-wrap">
        <div className="cross-string left">
          <div className="string-line" />
          <svg width="28" height="40" viewBox="0 0 28 40" xmlns="http://www.w3.org/2000/svg">
            <rect x="12" y="0" width="4" height="40" fill="var(--gold)" />
            <rect x="2" y="14" width="24" height="4" fill="var(--gold)" />
          </svg>
          <div className="string-line" />
        </div>
        <div className="cross-string right">
          <div className="string-line" />
          <svg width="28" height="40" viewBox="0 0 28 40" xmlns="http://www.w3.org/2000/svg">
            <rect x="12" y="0" width="4" height="40" fill="var(--gold)" />
            <rect x="2" y="14" width="24" height="4" fill="var(--gold)" />
          </svg>
          <div className="string-line" />
        </div>
        <div className="sponsored-block" style={{
          margin: '-30px auto 0 auto',
          maxWidth: '1000px',
          minHeight: '480px',
          border: '1px solid #eee',
          padding: '40px',
          background: '#fff',
          borderRadius: '8px',
          position: 'relative',
          zIndex: 2,
          boxShadow: '0 16px 30px rgba(15,36,56,0.25)',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center'
        }}>
          <div className="sponsored-tag-wrap">
            <span className="sponsored-ad-label">{t("home.sponsored.adLabel")}</span>
            <button
              type="button"
              className="sponsored-close"
              aria-label={t("home.sponsored.closeAriaLabel")}
              onClick={() => setShowSponsored(false)}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M5 5L19 19M19 5L5 19" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
            </button>
          </div>
          <span style={{ fontSize: '0.75rem', fontWeight: 'bold', color: '#d32f2f', textTransform: 'uppercase', marginBottom: '10px', display: 'block' }}>
            {t("home.sponsored.sponsoredContent")}
          </span>
          <div className="sponsored-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px', alignItems: 'center', width: '100%' }}>
            <img
              src={promotion?.image || promotion?.photo || promotion?.photoUrl || promotion?.imageUrl}
              alt={stripHtml(promotion?.title) || t("home.sponsored.imageAltFallback")}
              onClick={() => promotion?.id && navigate(`/promotions/${promotion.id}`)}
              style={{ width: '100%', aspectRatio: '16/9', objectFit: 'cover', borderRadius: '4px', cursor: promotion?.id ? 'pointer' : 'default' }}
            />
            <div>
              <h3 style={{ fontSize: '1.8rem', margin: '0 0 15px 0', fontFamily: 'Georgia, serif' }}>
                <Rich html={promotion?.title} />
              </h3>
              {/* <div>, not <p>: RichTextView renders block HTML */}
              <div style={{ fontSize: '1.1rem', color: '#555', margin: '0 0 20px 0' }}>
                <Rich html={promotion?.description} words={50} />
              </div>
              <button
                type="button"
                onClick={() => {
                  if (promotion?.id) {
                    navigate(`/promotions/${promotion.id}`);
                  } else if (promotion?.link) {
                    window.open(promotion.link, "_blank", "noopener,noreferrer");
                  }
                }}
                style={{
                  backgroundColor: '#d32f2f',
                  color: '#fff',
                  border: 'none',
                  padding: '12px 30px',
                  fontSize: '1rem',
                  fontWeight: 'bold',
                  textTransform: 'uppercase',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  transition: 'background 0.3s'
                }} onMouseOver={(e) => e.target.style.backgroundColor = '#b71c1c'}
                onMouseOut={(e) => e.target.style.backgroundColor = '#d32f2f'}>
                {t("home.sponsored.openButton")}
              </button>
              {/* note shown when the promotion fell back to English */}
              {promotionFallback && (
                <p style={{ textAlign: 'center', fontSize: '0.8rem', color: '#888', margin: '10px 0 0 0' }}>
                  {t("home.sponsored.fallbackNotice", "Showing this promotion in English.")}
                </p>
              )}
              {/* dots indicating position within the rotating promotion list */}
              {promotions.length > 1 && (
                <div style={{ display: 'flex', gap: '6px', marginTop: '14px' }}>
                  {promotions.map((_, i) => (
                    <span
                      key={i}
                      onClick={() => setPromotionIndex(i)}
                      style={{
                        width: '8px',
                        height: '8px',
                        borderRadius: '50%',
                        cursor: 'pointer',
                        background: i === promotionIndex ? '#d32f2f' : '#ddd',
                        display: 'inline-block',
                      }}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      )}

      <section style={{ padding: '100px 0 80px 0', background: 'linear-gradient(180deg, var(--navy) 0%, var(--navy-deep) 100%)' }}>
        <div className="wrapper" style={{ display: 'flex', alignItems: 'center', gap: '64px', flexWrap: 'wrap', minHeight: heroLoading ? '320px' : 'auto' }}>
          {heroLoading ? (
            <div style={{ width: '100%' }}>
              <Spinner light />
            </div>
          ) : (
            <>
              <div style={{ flex: '1', minWidth: '320px' }}>
                <Link to={`/homeheros/${hero?.id}`} style={{ textDecoration: 'none', color: 'inherit', display: 'block' }}>
                  <h1 className="display" style={{ fontSize: 'clamp(1rem, 6vw, 3rem)', fontWeight: 700, lineHeight: 1.08, margin: '0 0 26px 0', color: '#eaf3f8' }}>
                    <Rich html={hero?.title} fallback={t("home.hero.titleFallback")} />
                  </h1>
                  <div style={{ fontSize: '1.4rem', color: '#a9c2d3', lineHeight: 1.65, marginBottom: '36px', maxWidth: '520px' }}>
                    <Rich html={hero?.description} words={50} fallback={t("home.hero.descriptionFallback")} />
                  </div>
                </Link>
                <div className="hero-cta-row" style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
                  <button
                    type="button"
                    className="hero-cta-btn"
                    onClick={() => {
                      window.scrollTo({ top: 0, behavior: "smooth" });
                      navigate('/skill');
                    }}
                    style={{ backgroundColor: 'var(--gold)', color: 'var(--navy-deep)', border: 'none', padding: '15px 34px', fontSize: '1.05rem', fontWeight: 700, cursor: 'pointer', borderRadius: '30px' }}
                  >
                    {t("home.hero.watchSermonButton")}
                  </button>
                  <button
                    type="button"
                    className="hero-cta-btn"
                    onClick={() => {
                      window.scrollTo({ top: 0, behavior: "smooth" });
                      navigate('/contact');
                    }}
                    style={{ backgroundColor: 'transparent', color: '#eaf3f8', border: '1.5px solid #eaf3f8', padding: '15px 34px', fontSize: '1.05rem', fontWeight: 700, cursor: 'pointer', borderRadius: '30px' }}
                  >
                    {t("home.hero.planVisitButton")}
                  </button>
                </div>
                {/* note shown when the hero fell back to English */}
                {heroFallback && (
                  <p style={{ fontSize: '0.85rem', color: '#a9c2d3', margin: '18px 0 0 0' }}>
                    {t("home.hero.fallbackNotice", "Showing hero content in English — none available in your selected language yet.")}
                  </p>
                )}
              </div>
              <div style={{ flex: '0 0 480px', minWidth: '320px' }}>
                <Link to={`/homeheros/${hero?.id}`}>
                  <img
                    src={hero?.image || "https://images.unsplash.com/photo-1602802490525-79e3e5062d1b?auto=format&fit=crop&w=900&q=80"}
                    alt={stripHtml(hero?.title) || t("home.hero.imageAltFallback")}
                    style={{ width: '100%', aspectRatio: '1 / 1', objectFit: 'cover', borderRadius: '18px', boxShadow: '0 24px 40px rgba(15,36,56,0.35)' }}
                  />
                </Link>
              </div>
            </>
          )}
        </div>
      </section>

      {/* NAV — inlined (formerly <CategoryNav />) */}
      <nav className="cat-nav-bar" aria-label={t("home.categoryNav.ariaLabel")} ref={catNavBarRef}>
        <div
          className="cat-nav-track"
          ref={catViewportRef}
          onPointerDown={startCatDrag}
          onPointerMove={moveCatDrag}
          onPointerUp={endCatDrag}
          onPointerCancel={endCatDrag}
        >
          <div className="cat-nav-scroll" ref={catTrackRef}>
            {catLoopItems.map((cat, i) => (
              <span
                key={`${cat.slug}-${i}`}
                data-cat={cat.slug}
                className={`cat-nav-item${cat.slug === activeCategory ? " active" : ""}`}
              >
                {cat.slug === "all" ? t("home.categoryNav.all") : cat.name}
              </span>
            ))}
          </div>
        </div>
      </nav>

      {/* note shown when categories fell back to English */}
      {categoriesFallback && (
        <p style={{ textAlign: 'center', fontSize: '0.85rem', color: '#888', margin: '8px 0 0 0' }}>
          {t("home.categoryNav.fallbackNotice", "Showing categories in English — none available in your selected language yet.")}
        </p>
      )}

      <section ref={sermonSectionRef} style={{ background: '#ffffff', position: 'relative', overflow: 'hidden' }}>
        <div className="hanging-cross left">
          <div className="hang-string" />
          <svg width="46" height="64" viewBox="0 0 46 64" xmlns="http://www.w3.org/2000/svg">
            <rect x="19" y="0" width="8" height="64" fill="var(--gold)" />
            <rect x="4" y="20" width="38" height="8" fill="var(--gold)" />
          </svg>
        </div>
        <div className="hanging-cross right">
          <div className="hang-string" />
          <svg width="46" height="64" viewBox="0 0 46 64" xmlns="http://www.w3.org/2000/svg">
            <rect x="19" y="0" width="8" height="64" fill="var(--gold)" />
            <rect x="4" y="20" width="38" height="8" fill="var(--gold)" />
          </svg>
        </div>
        <div className="wrapper" style={{ maxWidth: '1000px' }}>
          <h3 className="display" style={{ marginBottom: '44px', fontSize: '2.8rem', fontWeight: 700, textAlign: 'center', color: 'var(--navy-deep)' }}>{t("home.sermons.heading")}</h3>

          {sermonsError && <p style={{ color: 'red', textAlign: 'center' }}>{sermonsError}</p>}

          {/* note shown when sermons fell back to English */}
          {sermonsFallback && !sermonsError && (
            <p style={{ textAlign: 'center', fontSize: '0.9rem', color: '#888', marginTop: '-24px', marginBottom: '30px' }}>
              {t("home.sermons.fallbackNotice", "No posts in your selected language yet — showing English instead.")}
            </p>
          )}

          {sermonsLoading && sermons.length === 0 ? (
            <Spinner />
          ) : sermons.length === 0 ? (
            <p style={{ textAlign: 'center' }}>
              {activeCategory === "all"
                ? t("home.sermons.noneAll")
                : t("home.sermons.noneCategory", { category: activeCategoryLabel })}
            </p>
          ) : (
            sermons.map((item, index, arr) => (
              <React.Fragment key={item.id}>
                <Link to={`/projects/${item.id}`} className="sermon-item-grid" style={{
                  padding: '50px 0',
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: '40px',
                  alignItems: 'start',
                  textDecoration: 'none',
                  color: 'inherit'
                }}>
                  <img
                    src={item.imageUrl}
                    alt={stripHtml(item.title)}
                    style={{ width: '100%', aspectRatio: '16/9', objectFit: 'cover', borderRadius: '8px', boxShadow: '0 10px 20px rgba(0,0,0,0.1)' }}
                  />
                  <div style={{ marginTop: '-5px' }}>
                    <h3 style={{ fontSize: '2rem', margin: '0 0 15px 0', fontFamily: 'Georgia, serif', lineHeight: '1', fontWeight: '600', color: '#c1440e' }}>
                      <Rich html={item.title} />
                    </h3>
                    <div style={{ fontSize: '1.5rem', color: '#333', margin: 0, lineHeight: '1.6' }}>
                      <Rich html={item.description} words={37} />
                    </div>

                  </div>
                </Link>
                {index < arr.length - 1 && (
                  <div className="sermon-divider">
                    <span className="h-string" />
                    <svg width="16" height="24" viewBox="0 0 16 24" xmlns="http://www.w3.org/2000/svg">
                      <rect x="6" y="0" width="4" height="24" fill="var(--gold)" opacity="0.7" />
                      <rect x="0" y="5" width="16" height="4" fill="var(--gold)" opacity="0.7" />
                    </svg>
                    <svg width="22" height="32" viewBox="0 0 22 32" xmlns="http://www.w3.org/2000/svg">
                      <rect x="9" y="0" width="4" height="32" fill="var(--gold)" />
                      <rect x="1" y="12" width="20" height="4" fill="var(--gold)" />
                    </svg>
                    <svg width="16" height="24" viewBox="0 0 16 24" xmlns="http://www.w3.org/2000/svg">
                      <rect x="6" y="0" width="4" height="24" fill="var(--gold)" opacity="0.7" />
                      <rect x="0" y="5" width="16" height="4" fill="var(--gold)" opacity="0.7" />
                    </svg>
                    <span className="h-string" />
                  </div>
                )}
              </React.Fragment>
            ))
          )}

          {sermonsPage < sermonsTotalPages && (
            <div className="load-more-wrap">
              <button type="button" className="load-more-btn" onClick={handleLoadMoreSermons} disabled={sermonsLoading}>
                {sermonsLoading ? t("home.sermons.loadingMore") : t("home.sermons.loadMoreButton")}
              </button>
            </div>
          )}
        </div>
      </section>

      <section className="angel-divider">
        {/* wrapper-wide: lets the trending cards spread across a wider row */}
        <div className="wrapper wrapper-wide">
          <h3 className="display" style={{ marginBottom: '38px', fontSize: '2.8rem', fontWeight: 700, textAlign: 'center', color: '#ffffff' }}>{t("home.trending.heading")}</h3>

          {trendingError && <p style={{ color: '#ffb3b3', textAlign: 'center' }}>{trendingError}</p>}

          {/* note shown when trending fell back to English */}
          {trendingFallback && !trendingError && (
            <p style={{ textAlign: 'center', fontSize: '0.85rem', color: '#ddd', marginTop: '-14px', marginBottom: '20px' }}>
              {t("home.trending.fallbackNotice", "Showing trending posts in English.")}
            </p>
          )}

          {trendingLoading ? (
            <Spinner light />
          ) : (
          <div className="angel-carousel">
            <button type="button" className="angel-arrow left" aria-label={t("home.trending.scrollLeftAriaLabel")} onClick={() => scrollAngels(-1)}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15 4L7 12L15 20" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
            <div className="angel-grid" ref={angelScrollRef}>
              {trending.length === 0 ? (
                <p style={{ color: '#fff' }}>{t("home.trending.none")}</p>
              ) : (
                trending.map((post) => (
                  <Link
                    key={post.id}
                    to={`/projects/${post.id}`}
                    className="angel-box"
                    style={{ backgroundImage: `url(${post.imageUrl})` }}
                    role="img"
                    aria-label={stripHtml(post.title)}
                  >
                    <div className="angel-box-overlay">
                      <h4><Rich html={post.title} /></h4>
                      <div><Rich html={post.description} words={50} /></div>
                    </div>
                  </Link>
                ))
              )}
            </div>
            <button type="button" className="angel-arrow right" aria-label={t("home.trending.scrollRightAriaLabel")} onClick={() => scrollAngels(1)}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 4L17 12L9 20" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </div>
          )}

          {trendingTotalPages > 1 && (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px', marginTop: '25px' }}>
              <button
                type="button"
                onClick={() => goToTrendingPage(trendingPage - 1)}
                disabled={trendingPage === 1}
                style={pageButtonStyle(trendingPage === 1)}
              >
                {t("home.pagination.prev")}
              </button>
              <span style={{ fontSize: '14px', color: '#fff' }}>
                {t("home.pagination.pageInfo", { page: trendingPage, total: trendingTotalPages })}
              </span>
              <button
                type="button"
                onClick={() => goToTrendingPage(trendingPage + 1)}
                disabled={trendingPage === trendingTotalPages}
                style={pageButtonStyle(trendingPage === trendingTotalPages)}
              >
                {t("home.pagination.next")}
              </button>
            </div>
          )}
        </div>
      </section>

      <section style={{ background: '#ffffff' }}>
        {/* wrapper-wide: lets the recommended cards use more of the screen */}
        <div className="wrapper wrapper-wide">
          <h3 className="display" style={{ marginBottom: '38px', fontSize: '2.8rem', fontWeight: 700, textAlign: 'center', color: 'var(--navy-deep)' }}>{t("home.recommended.heading")}</h3>

          {recommendedError && <p style={{ color: 'red', textAlign: 'center' }}>{recommendedError}</p>}

          {/* note shown when recommended fell back to English */}
          {recommendedFallback && !recommendedError && (
            <p style={{ textAlign: 'center', fontSize: '0.85rem', color: '#888', marginTop: '-24px', marginBottom: '20px' }}>
              {t("home.recommended.fallbackNotice", "Showing recommended posts in English.")}
            </p>
          )}

          {recommendedLoading ? (
            <Spinner />
          ) : recommended.length === 0 ? (
            <p style={{ textAlign: 'center' }}>{t("home.recommended.none")}</p>
          ) : (
            <div className="recommended-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '26px' }}>
              {recommended.map((post) => (
                <Link key={post.id} to={`/projects/${post.id}`} className="card" style={{ overflow: 'hidden', cursor: 'pointer', transition: 'transform 0.25s ease', background: '#ffffff', backdropFilter: 'none', display: 'block', textDecoration: 'none', color: 'inherit' }}
                  onMouseOver={(e) => e.currentTarget.style.transform = 'translateY(-4px)'}
                  onMouseOut={(e) => e.currentTarget.style.transform = 'translateY(0)'}>
                  <img src={post.imageUrl} alt={stripHtml(post.title)} style={{ width: '100%', height: '180px', objectFit: 'cover', display: 'block', filter: 'brightness(1.25) saturate(1.1)' }} />
                  <div style={{ padding: '18px' }}>
                    <h4 className="display" style={{ fontSize: '2rem', fontWeight: 600, margin: '0 0 8px 0', color: '#a80070' }}><Rich html={post.title} /></h4>
                    <div style={{ fontSize: '1.6rem', color: '#000000', margin: 0 }}><Rich html={post.description} words={20} /></div>
                  </div>
                </Link>
              ))}
            </div>
          )}

          {recommendedTotalPages > 1 && (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px', marginTop: '25px' }}>
              <button
                type="button"
                onClick={() => goToRecommendedPage(recommendedPage - 1)}
                disabled={recommendedPage === 1}
                style={pageButtonStyle(recommendedPage === 1)}
              >
                {t("home.pagination.prev")}
              </button>
              <span style={{ fontSize: '14px', color: '#444' }}>
                {t("home.pagination.pageInfo", { page: recommendedPage, total: recommendedTotalPages })}
              </span>
              <button
                type="button"
                onClick={() => goToRecommendedPage(recommendedPage + 1)}
                disabled={recommendedPage === recommendedTotalPages}
                style={pageButtonStyle(recommendedPage === recommendedTotalPages)}
              >
                {t("home.pagination.next")}
              </button>
            </div>
          )}
        </div>
      </section>

      <div className="cross-bg" style={{ background: 'var(--deep-red)', position: 'relative', overflow: 'hidden' }}>
        <div className="cross-track left">
          {Array.from({ length: 8 }).map((_, i) => (
            <svg key={i} className="wave-cross" width="26" height="38" viewBox="0 0 26 38" xmlns="http://www.w3.org/2000/svg"
              style={{ animationDelay: `${i * 0.22}s` }}>
              <rect x="11" y="0" width="4" height="38" fill="rgba(255,255,255,0.18)" />
              <rect x="2" y="9" width="22" height="4" fill="rgba(255,255,255,0.18)" />
            </svg>
          ))}
        </div>
        <div className="cross-track right">
          {Array.from({ length: 8 }).map((_, i) => (
            <svg key={i} className="wave-cross" width="26" height="38" viewBox="0 0 26 38" xmlns="http://www.w3.org/2000/svg"
              style={{ animationDelay: `${i * 0.22 + 0.4}s` }}>
              <rect x="11" y="0" width="4" height="38" fill="rgba(255,255,255,0.18)" />
              <rect x="2" y="9" width="22" height="4" fill="rgba(255,255,255,0.18)" />
            </svg>
          ))}
        </div>
        <section style={{ textAlign: 'center' }}>
          <div className="wrapper">
            <h3 className="display" style={{ fontSize: 'clamp(2rem,  4vw, 3.8rem)', fontWeight: 700, margin: 0, color: '#ffffff' }}>
              {t("home.invite.line1")}<br/>{t("home.invite.line2")}
            </h3>
          </div>
        </section>

        <section>
          {priestLoading ? (
            <div className="wrapper">
              <Spinner light />
            </div>
          ) : (
          <Link to={`/about/${priest?.id}`} style={{
            maxWidth: '1000px',
            display: 'flex',
            gap: '50px',
            alignItems: 'center',    // text keeps its natural height; the photo is sized to match it
            flexWrap: 'wrap',
            padding: '40px',
            background: 'rgba(255,255,255,0.06)',
            border: '1px solid rgba(255,255,255,0.14)',
            borderRadius: '12px',
            backdropFilter: 'blur(6px)',
            textDecoration: 'none',
            color: 'inherit'
          }} className="wrapper about-card" >
            <img
              className="about-photo"
              src={priest?.image || "https://images.unsplash.com/photo-1776454660072-222a8bdf122e?auto=format&fit=crop&w=400&q=80"}
              alt={stripHtml(priest?.title) || t("home.priest.imageAltFallback")}
              style={{
                '--about-size': `${priestPhotoSize}px`,     // photo width
                '--about-height': `${priestTextHeight}px`,  // photo height = text height
                objectFit: 'cover',
                borderRadius: '10px',
                flexShrink: 0,
                border: '4px solid #fff',
                boxShadow: '0 8px 20px rgba(0,0,0,0.25)'
              }}
            />
            <div ref={priestTextRef} className="about-text" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <span className="eyebrow" style={{ color: 'var(--gold)', fontSize: '0.85rem', display: 'block', textAlign: 'center' }}>{t("home.priest.eyebrow")}</span>
              <h3 className="display" style={{ fontSize: '2.4rem', fontWeight: 700, margin: '12px 0 14px 0', color: '#ffffff' }}>
                <Rich html={priest?.title} fallback={t("home.priest.titleFallback")} />
              </h3>
              <div style={{ fontSize: '1.3rem', color: 'rgba(255,255,255,0.82)', lineHeight: 1.7, margin: 0 }}>
                <Rich html={priest?.description} words={70} fallback={t("home.priest.descriptionFallback")} />
              </div>
              {/* note shown when the priest/about content fell back to English */}
              {priestFallback && (
                <p style={{ fontSize: '0.8rem', color: 'rgba(255,255,255,0.6)', margin: '14px 0 0 0' }}>
                  {t("home.priest.fallbackNotice", "Showing this content in English — none available in your selected language yet.")}
                </p>
              )}
            </div>
          </Link>
          )}
        </section>
      </div>

      <div className="section-cross-divider">
        <span className="h-string" />
        <svg width="18" height="26" viewBox="0 0 18 26" xmlns="http://www.w3.org/2000/svg">
          <rect x="7" y="0" width="4" height="26" fill="var(--gold)" opacity="0.6" />
          <rect x="0" y="6" width="18" height="4" fill="var(--gold)" opacity="0.6" />
        </svg>
        <svg width="26" height="38" viewBox="0 0 26 38" xmlns="http://www.w3.org/2000/svg">
          <rect x="11" y="0" width="4" height="38" fill="var(--gold)" />
          <rect x="2" y="9" width="22" height="4" fill="var(--gold)" />
        </svg>
        <svg width="18" height="26" viewBox="0 0 18 26" xmlns="http://www.w3.org/2000/svg">
          <rect x="7" y="0" width="4" height="26" fill="var(--gold)" opacity="0.6" />
          <rect x="0" y="6" width="18" height="4" fill="var(--gold)" opacity="0.6" />
        </svg>
        <span className="h-string" />
      </div>

      <section style={{ background: '#ffffff', position: 'relative', overflow: 'hidden' }}>
        <div className="wrapper photo-wrapper" style={{ maxWidth: '1000px' }}>
          <h3 className="display" style={{ marginBottom: '44px', fontSize: '2.8rem', fontWeight: 700, textAlign: 'center', color: 'var(--navy-deep)' }}>{t("home.photos.heading")}</h3>
          {photosError && <p style={{ color: 'red', textAlign: 'center' }}>{photosError}</p>}

          {photosLoading ? (
            <Spinner />
          ) : photos.length === 0 ? (
            <p style={{ textAlign: 'center' }}>{t("home.photos.none")}</p>
          ) : (
            <div className="photo-carousel">
              <div className="photo-carousel-frame">
                <div className="photo-image-wrap" style={{ position: 'relative' }}>
                  <button
                    type="button"
                    className="photo-arrow left"
                    aria-label={t("home.photos.prevAriaLabel")}
                    onClick={showPrevPhoto}
                    disabled={photosPageLoading || (photoIndex === 0 && photosPage === 1)}
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M15 4L7 12L15 20" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </button>
                  <img
                    src={photos[photoIndex]?.mediaUrl}
                    alt={stripHtml(photos[photoIndex]?.title)}
                    onClick={() => photos[photoIndex]?.id && navigate(`/media/${photos[photoIndex].id}`)}
                    style={{ width: '100%', aspectRatio: '16/9', objectFit: 'contain', backgroundColor: '#f4f4f4', borderRadius: '8px', boxShadow: '0 10px 20px rgba(0,0,0,0.1)', cursor: photos[photoIndex]?.id ? 'pointer' : 'default' }}
                  />
                  {/* Overlay spinner shown only while turning to a new page —
                      the image/arrows underneath stay mounted the whole time
                      so Next/Prev never appears to "do nothing".
                      pointerEvents:none so it can never swallow clicks. */}
                  {photosPageLoading && (
                    <div style={{
                      position: 'absolute',
                      inset: 0,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      background: 'rgba(255,255,255,0.55)',
                      borderRadius: '8px',
                      pointerEvents: 'none',
                      zIndex: 2
                    }}>
                      <div className="loading-spinner" />
                    </div>
                  )}
                  <button
                    type="button"
                    className="photo-arrow right"
                    aria-label={t("home.photos.nextAriaLabel")}
                    onClick={showNextPhoto}
                    disabled={photosPageLoading || (photoIndex === photos.length - 1 && photosPage === photosTotalPages)}
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M9 4L17 12L9 20" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </button>
                </div>
                <div
                  style={{ marginTop: '26px', textAlign: 'center', cursor: photos[photoIndex]?.id ? 'pointer' : 'default' }}
                  onClick={() => photos[photoIndex]?.id && navigate(`/media/${photos[photoIndex].id}`)}
                >
                  <h3 style={{ fontSize: '2.6rem', margin: '0 0 15px 0', fontFamily: 'Georgia, serif', lineHeight: '1.1', fontWeight: '800', color: '#c1440e' }}>
                    <Rich html={photos[photoIndex]?.title} />
                  </h3>
                  <div style={{ fontSize: '1.3rem', color: '#333', margin: '0 auto', lineHeight: '1.6', maxWidth: '620px' }}>
                    {/* This block is not inside a <Link>, so links stay clickable */}
                    <Rich html={photos[photoIndex]?.description} words={50} unwrapLinks={false} />
                  </div>
                </div>
                <div className="photo-dots">
                  {photos.map((_, i) => (
                    <span
                      key={i}
                      className={`photo-dot${i === photoIndex ? ' active' : ''}`}
                      onClick={() => setPhotoIndex(i)}
                    />
                  ))}
                </div>
                {photosTotalPages > 1 && (
                  <p style={{ textAlign: 'center', fontSize: '14px', color: '#444', marginTop: '15px' }}>
                    {t("home.pagination.pageInfo", { page: photosPage, total: photosTotalPages })}
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </section>

    </div>
  );
};

export default Home;