import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useLocation } from "react-router-dom";
import API from "../api/api";
import "./ChurchSupport.css";
import Spinner from "../components/Spinner";

const ChurchSupport = () => {
  const { t, i18n } = useTranslation();
  const { hash } = useLocation();

  const [accountNumbers, setAccountNumbers] = useState([]);
  const [accountsLoading, setAccountsLoading] = useState(true);
  const [accountsError, setAccountsError] = useState(false);

  // Scroll to the section matching the URL hash (e.g. #accounts,
  // #volunteer) once the page has rendered. React Router doesn't do
  // this automatically on its own.
  useEffect(() => {
    if (!hash) return;

    const el = document.querySelector(hash);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [hash]);

  // Bank accounts are admin-managed and language-specific, fetched from
  // the backend so they can be updated without a redeploy. Accept-Language
  // tells resolveLanguage middleware which language's accounts to return,
  // same as church-story.
  useEffect(() => {
    const fetchAccounts = async () => {
      try {
        setAccountsLoading(true);
        setAccountsError(false);

        const res = await API.get("/bank-accounts", {
          headers: { "Accept-Language": i18n.language },
        });

        setAccountNumbers(res.data.accounts || []);
      } catch (err) {
        console.error(err);
        setAccountsError(true);
      } finally {
        setAccountsLoading(false);
      }
    };

    fetchAccounts();
  }, [i18n.language]);

  // Pulled from translation files with returnObjects, same pattern as
  // Contact.jsx's quickFacts / reachMethods / serviceTimes.
  const volunteerActivitiesRaw = t("churchSupport.volunteer.items", {
    returnObjects: true,
  });
  const volunteerActivities = Array.isArray(volunteerActivitiesRaw)
    ? volunteerActivitiesRaw
    : [];

  const supportWaysRaw = t("churchSupport.ways.items", {
    returnObjects: true,
  });
  const supportWays = Array.isArray(supportWaysRaw) ? supportWaysRaw : [];

  return (
    <main className="church-support-page">
      {/* HERO */}
      <section className="support-hero">
        <div className="support-container">
          <span className="support-eyebrow">
            {t("churchSupport.hero.eyebrow")}
          </span>

          <h1>{t("churchSupport.hero.title")}</h1>

          <p>{t("churchSupport.hero.description")}</p>
        </div>
      </section>

      {/* ACCOUNT NUMBERS */}
      <section
        className="support-section account-section"
        id="accounts"
      >
        <div className="support-container">
          <div className="section-heading">
            <span className="support-eyebrow">
              {t("churchSupport.accounts.eyebrow")}
            </span>

            <h2>{t("churchSupport.accounts.title")}</h2>

            <p>{t("churchSupport.accounts.description")}</p>
          </div>

          {accountsLoading ? (
            <Spinner />
          ) : accountsError ? (
            <p>{t("churchSupport.accounts.error")}</p>
          ) : (
            <div className="account-table-wrapper">
              <table className="account-table">
                <thead>
                  <tr>
                    <th>{t("churchSupport.accounts.table.number")}</th>
                    <th>{t("churchSupport.accounts.table.bank")}</th>
                    <th>{t("churchSupport.accounts.table.holder")}</th>
                    <th>{t("churchSupport.accounts.table.account")}</th>
                  </tr>
                </thead>

                <tbody>
                  {accountNumbers.map((account, index) => (
                    <tr key={account.id}>
                      <td data-label={t("churchSupport.accounts.table.number")}>
                        {index + 1}
                      </td>

                      <td data-label={t("churchSupport.accounts.table.bank")}>
                        <strong>{account.bank}</strong>
                      </td>

                      <td data-label={t("churchSupport.accounts.table.holder")}>
                        {account.accountName}
                      </td>

                      <td data-label={t("churchSupport.accounts.table.account")}>
                        <span className="account-number">
                          {account.accountNumber}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="account-note">
            <span className="note-icon">i</span>

            <p>{t("churchSupport.accounts.note")}</p>
          </div>
        </div>
      </section>

      {/* VOLUNTEER ACTIVITIES */}
      <section
        className="support-section volunteer-section"
        id="volunteer"
      >
        <div className="support-container">
          <div className="section-heading light-heading">
            <span className="support-eyebrow">
              {t("churchSupport.volunteer.eyebrow")}
            </span>

            <h2>{t("churchSupport.volunteer.title")}</h2>

            <p>{t("churchSupport.volunteer.description")}</p>
          </div>

          <div className="volunteer-grid">
            {volunteerActivities.map((activity, i) => (
              <article className="volunteer-card" key={activity.title || i}>
                <div className="support-icon">{activity.icon}</div>

                <h3>{activity.title}</h3>

                <p>{activity.description}</p>

                <div className="card-line" />
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* OTHER WAYS TO SUPPORT */}
      <section className="support-section ways-section">
        <div className="support-container">
          <div className="section-heading">
            <span className="support-eyebrow">
              {t("churchSupport.ways.eyebrow")}
            </span>

            <h2>{t("churchSupport.ways.title")}</h2>

            <p>{t("churchSupport.ways.description")}</p>
          </div>

          <div className="ways-grid">
            {supportWays.map((way, i) => (
              <article className="way-card" key={way.title || i}>
                <div className="way-icon">{way.icon}</div>

                <div>
                  <h3>{way.title}</h3>
                  <p>{way.description}</p>
                </div>
              </article>
            ))}
          </div>

          <div className="support-cta">
            <div>
              <span className="support-eyebrow">
                {t("churchSupport.cta.eyebrow")}
              </span>

              <h3>{t("churchSupport.cta.title")}</h3>

              <p>{t("churchSupport.cta.description")}</p>
            </div>

            <a href="/contact" className="support-contact-btn">
              {t("churchSupport.cta.contactButton")}
            </a>
          </div>
        </div>
      </section>
    </main>
  );
};

export default ChurchSupport;