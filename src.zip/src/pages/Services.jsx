import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";
import API from "../api/api";
import { stripHtml } from "../components/RichTextView";
import "./Services.css";

/**
 * Public Services page.
 *
 * Services are now fetched from the backend (same API client/pattern used
 * in ManageServices.jsx) instead of a hardcoded array. Only services with
 * status "active" are shown to visitors.
 *
 * Uses the same outer shell as ChurchBlogPage.jsx (home page):
 * drifting cloud layer and site footer — so this page reads as part
 * of the same site.
 *
 * Styles live in Services.css (imported above) rather than an inline
 * <style> block.
 *
 * Clicking a service's photo or text navigates to its detail page
 * (/services/:id), handled by ServiceDetail.jsx.
 *
 * REMOVED: the red call-to-action section at the bottom of the page
 * (services.cta.title / services.cta.description) is no longer rendered.
 *
 * RICH TEXT: title / description / schedule / location are RichTextField
 * HTML. This page only shows them as list cards (the full formatted
 * description lives on ServiceDetail.jsx), so each service carries plain
 * versions (plainTitle, plainDescription, plainSchedule, plainLocation)
 * with tags stripped once when the data is mapped.
 */
const Services = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();

  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [visibleCount, setVisibleCount] = useState(10);
  // NEW: true when the services currently shown came from the English
  // fallback because the active language had none
  const [servicesFallback, setServicesFallback] = useState(false);

  // Reusable inline loading spinner — shown while a section's data is
  // being fetched from the backend, so no hardcoded frontend placeholder
  // content is ever visible before the real data arrives. Same
  // markup/classes as Home.jsx's Spinner, so it renders identically.
  const Spinner = ({ light }) => (
    <div className="loading-spinner-wrap">
      <div className={`loading-spinner${light ? " light" : ""}`} />
    </div>
  );

  // Turns whatever the API sends back for imageUrl (a full URL, or just a
  // filename/relative path saved from an upload) into a usable <img src>.
  const getImageUrl = (imageUrl) => {
    if (!imageUrl) return null;
    if (/^https?:\/\//i.test(imageUrl)) return imageUrl; // already a full URL
    const base = (API.defaults.baseURL || "").replace(/\/api\/?$/, "");
    const path = imageUrl.startsWith("/") ? imageUrl : `/uploads/${imageUrl}`;
    return `${base}${path}`;
  };

  // Keep only active services and add resolved image URL + plain-text
  // versions of the rich-text fields.
  const prepareServices = (data) =>
    (data?.services || [])
      .filter((s) => s.status === "active")
      .map((s) => ({
        ...s,
        resolvedImageUrl: getImageUrl(s.imageUrl),
        plainTitle: stripHtml(s.title),
        plainDescription: stripHtml(s.description),
        plainSchedule: stripHtml(s.schedule),
        plainLocation: stripHtml(s.location),
      }));

  // === Fetch services, same Accept-Language fallback pattern used
  // elsewhere on the site (Blog, Travel, About): try the active language
  // first, and if it comes back with no active services, retry with an
  // explicit "en" header and flag it. ===
  //
  // FIX: GET /services returns a paginated wrapper object —
  // { services, currentPage, totalPages, totalServices } — not a bare
  // array. This was reading res.data directly and calling .filter() on
  // that object, which threw (objects have no .filter) and silently
  // killed the fetch, so nothing ever rendered. Now reads res.data.services.
  const fetchServices = async () => {
    try {
      setLoading(true);
      setError("");
      setServicesFallback(false);

      let res = await API.get("/services");
      let active = prepareServices(res.data);

      if (active.length === 0) {
        res = await API.get("/services", {
          headers: { "Accept-Language": "en" },
        });
        active = prepareServices(res.data);
        if (active.length > 0) setServicesFallback(true);
      }

      setServices(active);
    } catch (err) {
      setError(err.response?.data?.message || t("services.list.errorDefault"));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchServices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [t]);

  const goToDetail = (id) => {
    if (id) navigate(`/services/${id}`);
  };

  return (
    <div className="services-portal">
      <div className="cloud-layer">
        <div className="cloud cloud-a" />
        <div className="cloud cloud-b" />
        <div className="cloud cloud-c" />
      </div>

      <section className="services-hero">
        <div className="wrapper">
          <h1 className="display">{t("services.hero.title")}</h1>
          <p>{t("services.hero.description")}</p>
        </div>
      </section>

      <section className="services-list">
        <div className="wrapper">
          {loading && <Spinner />}

          {!loading && error && (
            <p style={{ textAlign: "center", color: "#dc2626" }}>{error}</p>
          )}

          {!loading && !error && servicesFallback && (
            <p style={{ textAlign: "center", fontSize: "0.85rem", color: "#888", marginBottom: "24px" }}>
              {t("services.list.fallbackNotice")}
            </p>
          )}

          {!loading && !error && services.length === 0 && (
            <p style={{ textAlign: "center" }}>{t("services.list.none")}</p>
          )}

          {!loading && !error && services.slice(0, visibleCount).map((s, i) => (
            <div className={`service-row${i % 2 === 1 ? " reverse" : ""}`} key={s.id || i}>
              <div
                className="service-img"
                onClick={() => goToDetail(s.id)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") goToDetail(s.id);
                }}
              >
                {s.resolvedImageUrl ? (
                  <img src={s.resolvedImageUrl} alt={s.plainTitle} />
                ) : (
                  <div className="service-img-placeholder" aria-hidden="true" />
                )}
              </div>
              <div
                className="service-copy"
                onClick={() => goToDetail(s.id)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") goToDetail(s.id);
                }}
              >
                <svg className="service-cross" width="22" height="32" viewBox="0 0 22 32" xmlns="http://www.w3.org/2000/svg">
                  <rect x="9" y="0" width="4" height="32" fill="var(--gold)" />
                  <rect x="1" y="12" width="20" height="4" fill="var(--gold)" />
                </svg>
                <h2>{s.plainTitle}</h2>
                <p className="time">{s.plainSchedule}{s.plainLocation ? ` · ${s.plainLocation}` : ""}</p>
                {s.isFeatured && <p className="note">{t("services.list.featuredNote")}</p>}
                <p className="desc">{s.plainDescription}</p>
              </div>
            </div>
          ))}

          {!loading && !error && services.length > visibleCount && (
            <div className="load-more-wrap">
              <button
                className="load-more-btn"
                onClick={() => setVisibleCount((c) => c + 10)}
              >
                {t("services.list.loadMoreButton")}
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Services;