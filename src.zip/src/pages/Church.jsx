import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import API from "../api/api";
import RichTextView, { stripHtml } from "../components/RichTextView";
import "./Church.css";

const Church = () => {
  const { t, i18n } = useTranslation();

  const [showConstructionAd, setShowConstructionAd] = useState(false);

  const [primaryChurch, setPrimaryChurch] = useState(null);
  const [primaryLoading, setPrimaryLoading] = useState(true);
  const [primaryError, setPrimaryError] = useState("");
  const [primaryFallback, setPrimaryFallback] = useState(false);

  const [currentChurch, setCurrentChurch] = useState(null);
  const [currentLoading, setCurrentLoading] = useState(true);
  const [currentError, setCurrentError] = useState("");
  const [currentFallback, setCurrentFallback] = useState(false);

  const [blogChurches, setBlogChurches] = useState([]);
  const [blogPage, setBlogPage] = useState(1);
  const [blogLoading, setBlogLoading] = useState(true);
  const [blogLoadingMore, setBlogLoadingMore] = useState(false);
  const [blogError, setBlogError] = useState("");
  const [hasMoreBlog, setHasMoreBlog] = useState(true);
  const [blogFallback, setBlogFallback] = useState(false);

  const BLOG_LIMIT = 20;

  const Spinner = ({ light }) => (
    <div className="loading-spinner-wrap">
      <div className={`loading-spinner${light ? " light" : ""}`} />
    </div>
  );

  useEffect(() => {
    const timer = setTimeout(() => setShowConstructionAd(true), 5000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    fetchPrimaryChurch();
    fetchCurrentChurch();
    fetchBlogChurches(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [t]);

  const fetchPrimaryChurch = async () => {
    try {
      setPrimaryLoading(true);
      setPrimaryError("");
      setPrimaryFallback(false);

      let res = await API.get(`/churches/primary`);
      let data = res.data || null;

      if (!data || (!data.churchName && !data.name)) {
        res = await API.get(`/churches/primary`, {
          headers: { "Accept-Language": "en" },
        });
        data = res.data || null;
        if (data) setPrimaryFallback(true);
      }

      setPrimaryChurch(data);
    } catch (err) {
      console.log(err);
      if (err.response?.status === 404) {
        setPrimaryChurch(null);
      } else {
        setPrimaryError(err.response?.data?.message || t("church.errors.primaryDefault"));
      }
    } finally {
      setPrimaryLoading(false);
    }
  };

  const fetchCurrentChurch = async () => {
    try {
      setCurrentLoading(true);
      setCurrentError("");
      setCurrentFallback(false);

      let res = await API.get(`/churches/current`);
      let data = res.data || null;

      if (!data || (!data.church && !data.role)) {
        res = await API.get(`/churches/current`, {
          headers: { "Accept-Language": "en" },
        });
        data = res.data || null;
        if (data) setCurrentFallback(true);
      }

      setCurrentChurch(data);
    } catch (err) {
      console.log(err);
      if (err.response?.status === 404) {
        setCurrentChurch(null);
      } else {
        setCurrentError(err.response?.data?.message || t("church.errors.currentDefault"));
      }
    } finally {
      setCurrentLoading(false);
    }
  };

  const fetchBlogChurches = async (page) => {
    try {
      if (page === 1) {
        setBlogLoading(true);
        setBlogFallback(false);
      } else {
        setBlogLoadingMore(true);
      }
      setBlogError("");

      let res = await API.get(`/churches?page=${page}&limit=${BLOG_LIMIT}`);
      let newChurches = res.data.churches || res.data.data || res.data || [];
      let totalPages = res.data.totalPages;
      let usedFallback = false;

      if (page === 1 && newChurches.length === 0) {
        res = await API.get(`/churches?page=${page}&limit=${BLOG_LIMIT}`, {
          headers: { "Accept-Language": "en" },
        });
        newChurches = res.data.churches || res.data.data || res.data || [];
        totalPages = res.data.totalPages;
        if (newChurches.length > 0) usedFallback = true;
      }

      setBlogChurches((prev) => (page === 1 ? newChurches : [...prev, ...newChurches]));
      setBlogPage(page);
      if (page === 1) setBlogFallback(usedFallback);

      if (totalPages != null) {
        setHasMoreBlog(page < totalPages);
      } else {
        setHasMoreBlog(newChurches.length === BLOG_LIMIT);
      }
    } catch (err) {
      console.log(err);
      setBlogError(err.response?.data?.message || t("church.errors.blogDefault"));
    } finally {
      setBlogLoading(false);
      setBlogLoadingMore(false);
    }
  };

  const handleLoadMoreBlog = () => {
    if (!blogLoadingMore && hasMoreBlog) {
      fetchBlogChurches(blogPage + 1);
    }
  };

  const dismissConstructionAd = () => setShowConstructionAd(false);

  const renderLabel = (value, fallback = "") => {
    if (!value) return fallback;
    if (typeof value === "string") return value;
    if (typeof value === "object") return value.name || value.title || fallback;
    return fallback;
  };

  // PostgreSQL/Prisma returns `id`, not MongoDB `_id`
  const currentChurchId = currentChurch?.church?.id;
  const visibleBlogChurches = currentChurchId
    ? blogChurches.filter((c) => c.id !== currentChurchId)
    : blogChurches;

  return (
    <div className="church-page">
      <section className="church-hero">
        <div className="wrapper church-hero-inner">
          <div className="church-hero-text">
            <span className="eyebrow">{t("church.hero.eyebrow")}</span>
            {primaryLoading ? (
              <div style={{ width: "100%" }}>
                <Spinner light />
              </div>
            ) : primaryError ? (
              <p style={{ color: "red" }}>{primaryError}</p>
            ) : primaryChurch ? (
              <>
                <h1 className="display">{stripHtml(primaryChurch.churchName)}</h1>
                <RichTextView html={primaryChurch.shortDescription || primaryChurch.description} />
              </>
            ) : (
              <>
                <h1 className="display">{t("church.hero.fallbackTitle")}</h1>
                <p>{t("church.hero.fallbackDescription")}</p>
              </>
            )}
            {primaryChurch && primaryFallback && (
              <p style={{ fontSize: "0.85rem", color: "#888", marginTop: "4px" }}>
                {t("church.blog.fallbackNotice")}
              </p>
            )}
            <button className="hero-cta">{t("church.hero.cta")}</button>
          </div>
          <div className="church-hero-media">
            {primaryChurch?.id ? (
              <Link to={`/churches/${primaryChurch.id}`}>
                <img
                  src={
                    primaryChurch?.image ||
                    "https://images.unsplash.com/photo-1438032005730-c779502df39b?auto=format&fit=crop&w=1600&q=80"
                  }
                  alt={stripHtml(primaryChurch?.churchName) || t("church.hero.imageAlt")}
                />
              </Link>
            ) : (
              <img
                src={
                  primaryChurch?.image ||
                  "https://images.unsplash.com/photo-1438032005730-c779502df39b?auto=format&fit=crop&w=1600&q=80"
                }
                alt={stripHtml(primaryChurch?.churchName) || t("church.hero.imageAlt")}
              />
            )}
          </div>
        </div>
      </section>

      {showConstructionAd && (
        <div style={{ background: "var(--navy-deep)", padding: "1px 24px 40px 24px" }}>
          <div className="construction-ad visible">
            <div className="construction-ad-img-wrap">
              <img
                src="https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=900&q=80"
                alt={t("church.constructionAd.imageAlt")}
              />
              <span className="construction-ad-badge">{t("church.constructionAd.badge")}</span>
            </div>
            <button
              className="construction-ad-close"
              onClick={dismissConstructionAd}
              aria-label={t("church.constructionAd.closeAria")}
            >
              <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M6 6L18 18M18 6L6 18"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              </svg>
            </button>
            <div className="construction-ad-body">
              <span className="eyebrow">{t("church.constructionAd.eyebrow")}</span>
              <h3>{t("church.constructionAd.title")}</h3>
              <p>{t("church.constructionAd.description")}</p>
              <div className="ad-progress-label">
                <span>{t("church.constructionAd.progressLabel")}</span>
                <strong>{t("church.constructionAd.progressValue")}</strong>
              </div>
              <div className="ad-progress-track">
                <div className="ad-progress-fill" style={{ width: "62%" }} />
              </div>
              <button className="construction-ad-support-btn">
                {t("church.constructionAd.cta")}
              </button>
            </div>
          </div>
        </div>
      )}

      <section className="serve-now-section">
        <div className="wrapper">
          {currentLoading ? (
            <Spinner />
          ) : currentError ? (
            <p style={{ color: "red" }}>{currentError}</p>
          ) : !currentChurch ? (
            <p>{t("church.serveNow.none")}</p>
          ) : (
            <div className="serve-now-card">
              <div className="serve-now-img-wrap">
                {currentChurchId ? (
                  <Link to={`/churches/${currentChurchId}`}>
                    <img
                      src={
                        currentChurch.image ||
                        currentChurch.user?.image ||
                        currentChurch.church?.image ||
                        ""
                      }
                      alt={stripHtml(currentChurch.user?.name) || "Leader"}
                    />
                  </Link>
                ) : (
                  <img
                    src={
                      currentChurch.image ||
                      currentChurch.user?.image ||
                      currentChurch.church?.image ||
                      ""
                    }
                    alt={stripHtml(currentChurch.user?.name) || "Leader"}
                  />
                )}
                <span className="serve-now-badge">{t("church.serveNow.badge")}</span>
              </div>
              <div className="serve-now-body">
                <span className="serve-now-role">{renderLabel(currentChurch.role)}</span>
                <h2 className="display">{stripHtml(currentChurch.church?.churchName)}</h2>
                <div className="serve-now-since">
                  {currentChurch.servingSince &&
                    t("church.serveNow.since", {
                      year: new Date(currentChurch.servingSince).getFullYear(),
                    })}
                </div>
                <RichTextView className="serve-now-desc" html={currentChurch.description} />
                <div className="serve-now-details">
                  <div className="serve-now-line">
                    <strong>{t("church.serveNow.address")}</strong> {currentChurch.church?.address}
                  </div>
                  <div className="serve-now-line">
                    <strong>{t("church.serveNow.service")}</strong>{" "}
                    {currentChurch.church?.serviceDays} · {currentChurch.church?.serviceTime}
                  </div>
                </div>
                {currentFallback && (
                  <p style={{ fontSize: "0.85rem", color: "#888" }}>
                    {t("church.blog.fallbackNotice")}
                  </p>
                )}
                {currentChurchId ? (
                  <Link className="serve-now-cta" to={`/churches/${currentChurchId}`}>
                    {t("church.serveNow.cta")}
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M5 12H19M19 12L13 6M19 12L13 18"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </Link>
                ) : (
                  <button className="serve-now-cta" disabled>
                    {t("church.serveNow.cta")}
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M5 12H19M19 12L13 6M19 12L13 18"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </section>

      <section className="blog-section">
        <div className="wrapper">
          <div className="blog-head">
            <span className="eyebrow">{t("church.blog.eyebrow")}</span>
            <h2 className="display">{t("church.blog.title")}</h2>
            <p>{t("church.blog.description")}</p>
          </div>

          {blogLoading ? (
            <Spinner />
          ) : blogError ? (
            <p style={{ color: "red" }}>{blogError}</p>
          ) : visibleBlogChurches.length === 0 ? (
            <p>{t("church.blog.none")}</p>
          ) : (
            <>
              {blogFallback && (
                <p style={{ textAlign: "center", fontSize: "0.85rem", color: "#888", marginBottom: "24px" }}>
                  {t("church.blog.fallbackNotice")}
                </p>
              )}
              <div className="blog-grid">
                {visibleBlogChurches.map((c) => (
                  <div className="blog-card" key={c.id}>
                    <Link to={`/churches/${c.id}`}>
                      <img src={c.image || ""} alt={stripHtml(c.churchName)} />
                    </Link>
                    <div className="blog-card-body">
                      <div className="blog-tag">
                        {c.isPrimary
                          ? t("church.blog.tagPrimary")
                          : c.isFeatured
                          ? t("church.blog.tagFeatured")
                          : t("church.blog.tagDefault")}
                      </div>
                      <h3>{stripHtml(c.churchName)}</h3>
                      <p>{stripHtml(c.shortDescription || c.description)}</p>
                      <Link className="read-more" to={`/churches/${c.id}`}>
                        {t("church.blog.readMore")}
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path
                            d="M5 12H19M19 12L13 6M19 12L13 18"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>

              {hasMoreBlog && (
                <div style={{ display: "flex", justifyContent: "center", marginTop: "32px" }}>
                  <button
                    className="hero-cta"
                    onClick={handleLoadMoreBlog}
                    disabled={blogLoadingMore}
                  >
                    {blogLoadingMore ? t("church.blog.loadingMore") : t("church.blog.loadMore")}
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </section>
    </div>
  );
};

export default Church;