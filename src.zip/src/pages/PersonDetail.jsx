import { useTranslation } from "react-i18next";
import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import API from "../api/api.jsx";
import RichTextView, { stripHtml } from "../components/RichTextView";
import "./PersonDetail.css";
import Spinner from "../components/Spinner";

const PersonDetail = () => {
  const { t } = useTranslation();
  const { id } = useParams();
  const [entry, setEntry] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [id]);

  // FIX: leaders, special-thanks, and testimonials on ChurchAboutPage.jsx
  // all now link to /church-persons/:id — but this was only ever fetching
  // the "testimony" category, so any leader or specialThanks id came back
  // as "not found" (404). Fetching every category (no params) and finding
  // by id resolves all three link sources correctly.
  useEffect(() => {
    const fetchEntry = async () => {
      try {
        setLoading(true);
        setError("");
        const res = await API.get("/church-persons");
        const list = Array.isArray(res.data) ? res.data : [res.data];
        // PostgreSQL/Prisma returns `id`, not MongoDB `_id`
        const match = (list || []).find((p) => p.id === id);
        setEntry(match || null);
      } catch (err) {
        console.log(err);
        setError(err.response?.data?.message || t("common.errors.entry"));
      } finally {
        setLoading(false);
      }
    };
    fetchEntry();
  }, [id]);

  const BackButton = () => (
    <Link to="/about" aria-label={t("common.goBack")} className="person-detail-back-btn">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M15 4L7 12L15 20" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </Link>
  );

  if (loading) {
    return (
      <div className="church-portal">
        <BackButton />
        <div className="wrapper" style={{ padding: "80px 0", textAlign: "center" }}>
          <Spinner />
        </div>
      </div>
    );
  }

  if (error || !entry) {
    return (
      <div className="church-portal">
        <BackButton />
        <div className="wrapper" style={{ padding: "80px 0", textAlign: "center" }}>
          <p style={{ color: "red" }}>{error || t("common.notFound")}</p>
          <Link to="/about" style={{ color: "var(--gold, #b8860b)" }}>{t("common.backTo.about")}</Link>
        </div>
      </div>
    );
  }

  // name / role / title may be RichTextField HTML — plain-text versions
  // for the heading, tag line, alt text and avatar fallback.
  const plainName = stripHtml(entry.name);
  const plainRole = stripHtml(entry.role || entry.title);

  const photo =
    (entry.photos && entry.photos[0]) ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(plainName)}&background=0070f3&color=fff`;

  // Category-aware label + body text, since a leader, a special-thanks
  // entry, and a testimony all land on this same page but shape their
  // content a little differently (leaders/thanks use description,
  // testimonies use a quoted message).
  const labelByCategory = {
    leader: t("common.person.leadershipTeam"),
    specialThanks: t("common.person.specialThanks"),
    testimony: t("common.person.testimony"),
  };
  const label = labelByCategory[entry.category] || t("common.person.churchFamily");
  const bodyText = entry.message || entry.description;
  const isQuote = entry.category === "testimony";

  return (
    <div className="church-portal">
      <BackButton />

      <section className="person-detail-section">
        <div className="wrapper" style={{ maxWidth: "760px" }}>
          <span className="person-detail-label">{label}</span>

          <img loading="lazy" decoding="async" src={photo} alt={plainName} className="person-detail-photo" />

          {bodyText &&
            (isQuote ? (
              // Testimonies are wrapped in literal quotation marks, which
              // can't sit cleanly around block-level HTML — so the quote
              // is shown as plain text to keep the quoted look.
              <p className="person-detail-quote">{`"${stripHtml(bodyText)}"`}</p>
            ) : (
              <RichTextView className="person-detail-quote" html={bodyText} />
            ))}

          <h1 className="person-detail-name">{plainName}</h1>
          {plainRole && <p className="person-detail-title-tag">{plainRole}</p>}
        </div>
      </section>
    </div>
  );
};

export default PersonDetail;